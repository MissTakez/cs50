#include <stdio.h>

int main(void)
{
    int score1 = 72;
    int score2 = 73;
    int score3 = 33;

    printf("Avarage: %f\n", (score1 + score2 + score3) /(float) 3);
}
//if %f, u need, at least, 1 float number