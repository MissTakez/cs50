#include <cs50.h>
#include <stdio.h>

int main (void)
{
    while (true)
    {
        printf ("meow\n");
    }
}