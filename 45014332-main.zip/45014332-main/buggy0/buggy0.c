#include <stdio.h>

int main (void)
{
    for (int i = 0; i < 3; i++)
    {
        //first tool to debug - printf
        printf ("i is %i\n", i); -> //then u need to erease it.
        printf("#\n");
    }
}
 