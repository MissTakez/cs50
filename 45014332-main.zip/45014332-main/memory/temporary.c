//para fazer a brisa do temporário

//se quiser trocar dados, é necessário tem uma variável temporária

void swap(int a, int b)
{
    int tmp = a;
    a = b;
    b = tmp;
}